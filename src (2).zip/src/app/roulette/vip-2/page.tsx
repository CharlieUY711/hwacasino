"use client";

import RouletteLayout from "@/ui/Roulette/RouletteLayout";

export default function EsmeraldaPage() {
  return <RouletteLayout />;
}
