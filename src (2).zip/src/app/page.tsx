'use client'

import { useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { loginWithEmail } from '@/modules/auth/login'
import { registerWithEmail } from '@/modules/auth/register'
import { validateInviteCode, markInviteUsed } from '@/modules/auth/invite'

const TEMPLATE = 'VIP-0000-AAAA-0A0A'
const SLOT_TYPES: Array<'fixed' | 'digit' | 'alpha' | 'dash'> = [
  'fixed','fixed','fixed',
  'dash',
  'digit','digit','digit','digit',
  'dash',
  'alpha','alpha','alpha','alpha',
  'dash',
  'digit','alpha','digit','alpha',
]

const EDITABLE_INDICES = SLOT_TYPES
  .map((t, i) => (t !== 'fixed' && t !== 'dash' ? i : -1))
  .filter(i => i >= 0)

const GOLD = '#D4AF37'

export default function Home() {
  const router = useRouter()
  const [chars, setChars] = useState<string[]>(Array(TEMPLATE.length).fill(''))
  const [shake, setShake] = useState(false)
  const [submitted, setSubmitted] = useState<'idle' | 'success' | 'error'>('idle')
  const [statusMsg, setStatusMsg] = useState('')
  const [validating, setValidating] = useState(false)
  const [inviteId, setInviteId] = useState<string | null>(null)
  const [focusedIdx, setFocusedIdx] = useState<number>(-1)

  const [showLogin, setShowLogin] = useState(false)
  const [loginEmail, setLoginEmail] = useState('')
  const [loginPassword, setLoginPassword] = useState('')
  const [loginError, setLoginError] = useState<string | null>(null)
  const [loginLoading, setLoginLoading] = useState(false)

  const [showRegister, setShowRegister] = useState(false)
  const [regEmail, setRegEmail] = useState('')
  const [regPassword, setRegPassword] = useState('')
  const [regConfirm, setRegConfirm] = useState('')
  const [regError, setRegError] = useState<string | null>(null)
  const [regLoading, setRegLoading] = useState(false)

  // El usuario ha comenzado a completar el código
  const codeStarted = chars.some(c => c !== '')

  async function handleLogin() {
    setLoginError(null)
    if (!loginEmail || !loginPassword) { setLoginError('Completa todos los campos.'); return }
    setLoginLoading(true)
    try {
      await loginWithEmail(loginEmail, loginPassword)
      router.push('/lobby')
    } catch (err) {
      setLoginError(err instanceof Error ? err.message : 'Error inesperado.')
    } finally { setLoginLoading(false) }
  }

async function handleRegister() {
  setRegError(null)
  if (!regEmail || !regPassword || !regConfirm) { setRegError('Completa todos los campos.'); return }
  if (regPassword !== regConfirm) { setRegError('Las contraseñas no coinciden.'); return }
  if (regPassword.length < 6) { setRegError('Mínimo 6 caracteres.'); return }
  setRegLoading(true)
  try {
    const data = await registerWithEmail(regEmail, regPassword)
    const userId = data.user?.id
    if (inviteId && userId) await markInviteUsed(inviteId, userId)
    router.push('/lobby')
  } catch (err) {
    setRegError(err instanceof Error ? err.message : 'Error inesperado.')
  } finally { setRegLoading(false) }
}

  const handleValidate = useCallback(async () => {
    const allFilled = EDITABLE_INDICES.every(i => chars[i] !== '')
    if (!allFilled || validating || submitted === 'success') return
    const entered = TEMPLATE.split('').map((ch, i) => {
      if (SLOT_TYPES[i] === 'fixed') return ch
      if (SLOT_TYPES[i] === 'dash') return '-'
      return chars[i] || '_'
    }).join('')
    setValidating(true)
    setStatusMsg('VERIFICANDO...')
    const result = await validateInviteCode(entered)
    if (result.valid) {
      setInviteId(result.id)
      setSubmitted('success')
      setStatusMsg('CODIGO VALIDO')
      setShowRegister(true)
      setShowLogin(false)
    } else {
      setSubmitted('error')
      setStatusMsg('CODIGO INVALIDO')
      setShake(true)
      setTimeout(() => setShake(false), 500)
    }
    setValidating(false)
  }, [chars, validating, submitted])

  function handleSlotKey(e: React.KeyboardEvent<HTMLInputElement>, editIdx: number) {
    const realIdx = EDITABLE_INDICES[editIdx]
    e.preventDefault()
    if (e.key === 'Enter') { handleValidate(); return }
    if (e.key === 'Backspace') {
      setSubmitted('idle'); setStatusMsg(''); setShowRegister(false); setInviteId(null)
      setChars(prev => {
        const next = [...prev]
        if (prev[realIdx] !== '') {
          next[realIdx] = ''
        } else if (editIdx > 0) {
          const prevReal = EDITABLE_INDICES[editIdx - 1]
          next[prevReal] = ''
          setTimeout(() => document.getElementById(`slot-${editIdx - 1}`)?.focus(), 0)
        }
        return next
      })
      return
    }
    if (e.key === 'ArrowLeft' && editIdx > 0) { document.getElementById(`slot-${editIdx - 1}`)?.focus(); return }
    if (e.key === 'ArrowRight' && editIdx < EDITABLE_INDICES.length - 1) { document.getElementById(`slot-${editIdx + 1}`)?.focus(); return }
    const char = e.key.toUpperCase()
    if (char.length !== 1 || !/^[A-Za-z0-9]$/.test(char)) return
    const slotType = SLOT_TYPES[realIdx]
    const isDigit = slotType === 'digit' && /^[0-9]$/.test(char)
    const isAlpha = slotType === 'alpha' && /^[A-Za-z]$/.test(char)
    if (isDigit || isAlpha) {
      setSubmitted('idle'); setStatusMsg(''); setShowRegister(false); setInviteId(null)
      setChars(prev => { const n = [...prev]; n[realIdx] = char; return n })
      if (editIdx < EDITABLE_INDICES.length - 1)
        setTimeout(() => document.getElementById(`slot-${editIdx + 1}`)?.focus(), 0)
    }
  }

  function slotColor(realIdx: number): string {
    const type = SLOT_TYPES[realIdx]
    if (submitted === 'success') return GOLD
    if (submitted === 'error') return '#e05252'
    if (type === 'fixed') return 'rgba(255,255,255,0.85)'
    return chars[realIdx] !== '' ? 'rgba(255,255,255,0.85)' : 'rgba(255,255,255,0.18)'
  }

  const allFilled = EDITABLE_INDICES.every(i => chars[i] !== '')

  // Tipografía base unificada — usada en todos los campos y botones
  const baseFont: React.CSSProperties = {
    fontFamily: "'Montserrat', sans-serif",
    fontWeight: 300,
    fontSize: '0.75rem',
    letterSpacing: '0.1em',
  }

  // 70% del maxWidth original de los campos (340px × 0.7 ≈ 238px)
  const FORM_WIDTH = '238px'

  const fieldStyle: React.CSSProperties = {
    ...baseFont,
    width: FORM_WIDTH,
    height: '38px',
    background: 'rgba(255,255,255,0.09)',
    border: 'none', borderRadius: '2px',
    boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.8)',
    color: 'rgba(255,255,255,0.85)',
    padding: '0 12px', outline: 'none', boxSizing: 'border-box' as const,
  }

  const whiteBtnStyle: React.CSSProperties = {
    ...baseFont,
    width: FORM_WIDTH,
    height: '38px',
    background: 'rgba(255,255,255,0.90)',
    border: 'none', borderRadius: '2px', color: '#000',
    fontWeight: 700, letterSpacing: '0.35em',
    textTransform: 'uppercase' as const,
    cursor: 'pointer', transition: 'background 0.25s ease',
    boxSizing: 'border-box' as const,
  }

  const goldLinkStyle: React.CSSProperties = {
    background: 'transparent', border: 'none', boxShadow: 'none', padding: '0',
    fontFamily: "'Montserrat', sans-serif", fontWeight: 700, fontSize: '0.93rem',
    letterSpacing: '0.35em', color: GOLD, textTransform: 'uppercase' as const,
    cursor: 'pointer', outline: 'none', transition: 'opacity 0.25s ease',
  }

  let editCounter = 0

  return (
    <main style={{ minHeight: '100dvh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#000', position: 'relative', overflow: 'hidden' }}>

      <div className="corner-ornament tl animate-fade-in delay-1200" />
      <div className="corner-ornament tr animate-fade-in delay-1200" />
      <div className="corner-ornament bl animate-fade-in delay-1200" />
      <div className="corner-ornament br animate-fade-in delay-1200" />
      <div style={{ position: 'absolute', width: '520px', height: '520px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(212,175,55,0.04) 0%, transparent 70%)', pointerEvents: 'none' }} />

      {/* CONTENEDOR ÚNICO — el logo siempre ocupa el mismo lugar */}
      <div style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        width: '100%', maxWidth: '480px', padding: '0 24px',
        position: 'relative', zIndex: 10,
      }}>

        {/* LOGO — tamaño y posición fijos en todos los estados */}
        <div className="animate-fade-in delay-200" style={{ marginBottom: '20px' }}>
          <Image src="/logo-dorado.jpg" alt="HWA Casino" width={140} height={140} style={{ objectFit: 'contain' }} priority />
        </div>

        <p className="animate-fade-in-up delay-400" style={{ fontFamily: "'Montserrat', sans-serif", fontWeight: 200, fontSize: '0.6rem', letterSpacing: '0.55em', color: 'rgba(255,255,255,0.3)', textTransform: 'uppercase', marginBottom: '40px' }}>
          Private Members Only
        </p>

        <div className="line-expand" style={{ height: '1px', background: 'linear-gradient(90deg, transparent, rgba(212,175,55,0.4), transparent)', marginBottom: '40px', alignSelf: 'stretch' }} />

        {/* ── VISTA LOGIN ── */}
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center',
          overflow: 'hidden',
          maxHeight: showLogin ? '400px' : '0px',
          opacity: showLogin ? 1 : 0,
          transition: 'max-height 0.4s ease, opacity 0.35s ease',
          width: '100%',
        }}>
          <p style={{ ...baseFont, fontWeight: 200, fontSize: '0.58rem', letterSpacing: '0.45em', color: 'rgba(255,255,255,0.25)', textTransform: 'uppercase', marginBottom: '24px' }}>
            ACCESO MIEMBROS
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', alignItems: 'center', width: '100%', marginBottom: '24px' }}>
            <input type="email" placeholder="EMAIL" value={loginEmail} onChange={e => setLoginEmail(e.target.value)} style={fieldStyle} />
            <input type="password" placeholder="PASSWORD" value={loginPassword} onChange={e => setLoginPassword(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') handleLogin() }} style={fieldStyle} />
            <button onClick={handleLogin} disabled={loginLoading}
              style={{ ...whiteBtnStyle, opacity: loginLoading ? 0.5 : 1, cursor: loginLoading ? 'not-allowed' : 'pointer' }}>
              {loginLoading ? '...' : 'INGRESAR'}
            </button>
            {loginError && <p style={{ ...baseFont, fontSize: '0.6rem', letterSpacing: '0.15em', color: '#e05252', textAlign: 'center', margin: '4px 0 0' }}>{loginError}</p>}
          </div>
          <button onClick={() => setShowLogin(false)} style={{ ...goldLinkStyle, fontSize: '0.7rem', opacity: 0.5 }}>
            VOLVER
          </button>
          <div style={{ height: '32px' }} />
        </div>

        {/* ── VISTA CÓDIGO + REGISTRO ── */}
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center',
          overflow: 'hidden',
          maxHeight: showLogin ? '0px' : '700px',
          opacity: showLogin ? 0 : 1,
          transition: 'max-height 0.4s ease, opacity 0.35s ease',
          width: '100%',
        }}>

          <p style={{ ...baseFont, fontWeight: 200, fontSize: '0.58rem', letterSpacing: '0.45em', color: 'rgba(255,255,255,0.25)', textTransform: 'uppercase', marginBottom: '28px' }}>
            VIP CODE
          </p>

          {/* SLOTS */}
          <div className={shake ? 'error-shake' : ''} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '24px', userSelect: 'none', width: '88%', maxWidth: '340px' }}>
            {TEMPLATE.split('').map((_, realIdx) => {
              const type = SLOT_TYPES[realIdx]
              const color = slotColor(realIdx)

              if (type === 'dash') {
                return (
                  <span key={realIdx} style={{ color: GOLD, fontSize: '5px', margin: '0 5px', lineHeight: 1, display: 'flex', alignItems: 'center', paddingBottom: '2px' }}>
                    &#9679;
                  </span>
                )
              }

              const isEditable = type !== 'fixed'
              const currentEditIdx = isEditable ? editCounter++ : -1
              const displayChar = type === 'fixed' ? TEMPLATE[realIdx] : (chars[realIdx] || '')

              return (
                <span key={realIdx} style={{ display: 'inline-flex', flexDirection: 'column', alignItems: 'center', flex: '1 1 0', maxWidth: '22px', position: 'relative' }}>
                  {isEditable ? (
                    <input
                      id={`slot-${currentEditIdx}`}
                      maxLength={1}
                      value={chars[realIdx]}
                      onKeyDown={e => handleSlotKey(e, currentEditIdx)}
                      onChange={() => {}}
                      onFocus={() => setFocusedIdx(currentEditIdx)}
                      onBlur={() => setFocusedIdx(-1)}
                      style={{
                        width: '100%', height: '1.43rem',
                        background: 'transparent', border: 'none', outline: 'none',
                        textAlign: 'center', caretColor: 'transparent',
                        fontFamily: "'Montserrat', sans-serif",
                        fontWeight: 300, fontSize: '1.1rem',
                        color: displayChar ? color : 'transparent',
                        padding: 0, margin: 0,
                      }}
                    />
                  ) : (
                    <span style={{ fontFamily: "'Montserrat', sans-serif", fontWeight: 400, fontSize: '1.1rem', color, lineHeight: 1.3, minHeight: '1.43rem', textAlign: 'center', display: 'block', width: '100%' }}>
                      {displayChar}
                    </span>
                  )}
                  <span style={{ display: 'block', width: '100%', height: '1px', marginTop: '3px', background: focusedIdx === currentEditIdx ? GOLD : color, transition: 'background 0.2s ease' }} />
                </span>
              )
            })}
          </div>

          {/* STATUS */}
          <div style={{ ...baseFont, fontWeight: 300, fontSize: '0.58rem', letterSpacing: '0.3em', textTransform: 'uppercase', height: '20px', marginBottom: '20px', color: submitted === 'success' ? GOLD : submitted === 'error' ? '#e05252' : validating ? 'rgba(255,255,255,0.3)' : 'transparent', transition: 'color 0.3s ease' }}>
            {statusMsg}
          </div>

          {/* ── VALIDAR / LOGIN superpuestos, sin línea divisoria ── */}
          <div style={{ marginBottom: '28px', position: 'relative', height: '24px', width: '200px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {submitted === 'error' ? (
              <button onClick={() => { setChars(Array(TEMPLATE.length).fill('')); setSubmitted('idle'); setStatusMsg(''); setShowRegister(false); setInviteId(null) }}
                style={{ ...goldLinkStyle, color: '#e05252', position: 'absolute' }}>
                RESET CODE
              </button>
            ) : (
              <>
                {/* VALIDAR: negro al inicio → dorado al escribir */}
                <button
                  onClick={handleValidate}
                  disabled={!allFilled || submitted === 'success' || validating}
                  style={{
                    ...goldLinkStyle,
                    color: codeStarted ? GOLD : '#000',
                    position: 'absolute',
                    opacity: submitted === 'success' || validating ? 0.3 : 1,
                    transition: 'color 0.3s ease, opacity 0.3s ease',
                    pointerEvents: (!allFilled || submitted === 'success' || validating) ? 'none' : 'auto',
                  }}
                >
                  {validating ? '...' : 'VALIDAR'}
                </button>

                {/* LOGIN: dorado al inicio → desaparece al escribir */}
                <button
                  onClick={() => { setShowLogin(true); setShowRegister(false) }}
                  style={{
                    ...goldLinkStyle,
                    position: 'absolute',
                    opacity: codeStarted ? 0 : 1,
                    pointerEvents: codeStarted ? 'none' : 'auto',
                    transition: 'opacity 0.3s ease',
                  }}
                >
                  LOGIN
                </button>
              </>
            )}
          </div>

          {/* REGISTRO — aparece solo cuando el código es válido */}
          <div style={{ display: 'grid', gridTemplateRows: showRegister ? '1fr' : '0fr', transition: 'grid-template-rows 0.35s ease', width: '100%' }}>
            <div style={{ overflow: 'hidden' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', paddingBottom: '24px', alignItems: 'center' }}>
                <input type="email" placeholder="CORREO" value={regEmail} onChange={e => setRegEmail(e.target.value)} style={fieldStyle} />
                <input type="password" placeholder="CONTRASENA" value={regPassword} onChange={e => setRegPassword(e.target.value)} style={fieldStyle} />
                <input type="password" placeholder="CONFIRMAR CONTRASENA" value={regConfirm} onChange={e => setRegConfirm(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') handleRegister() }} style={fieldStyle} />
                <button onClick={handleRegister} disabled={regLoading}
                  style={{ ...whiteBtnStyle, opacity: regLoading ? 0.5 : 1, cursor: regLoading ? 'not-allowed' : 'pointer' }}>
                  {regLoading ? '...' : 'REGISTRAR'}
                </button>
                {regError && <p style={{ ...baseFont, fontSize: '0.6rem', letterSpacing: '0.15em', color: '#e05252', textAlign: 'center', margin: '4px 0 0' }}>{regError}</p>}
              </div>
            </div>
          </div>

        </div>

      </div>

    </main>
  )
}
