// ============================================================
// Public API of the realtime layer
// Import from here, not from internal paths
// ============================================================

// Hooks
export { useRouletteLive } from './hooks/useRouletteLive'
export { useLiveBets }     from './hooks/useLiveBets'
export { useWalletLive }   from './hooks/useWalletLive'
export { useRoomLive }     from './hooks/useRoomLive'

// Event normalization (for custom components)
export {
  normalizeRound,
  normalizeBet,
  normalizeTransaction,
  normalizeWallet,
  normalizeRoundStatus,
  aggregateBets,
} from './lib/realtime/events'

// Supabase client (if needed directly)
export { supabase } from './lib/realtime/subscriptions'

// Types
export type {
  UIRound,
  UIBet,
  UIBetSummary,
  UIWalletState,
  UITransaction,
  UIRoomState,
  RoundUIStatus,
  RealtimeEvent,
  RealtimeEventType,
  UseRouletteLiveReturn,
  UseLiveBetsReturn,
  UseWalletLiveReturn,
  UseRoomLiveReturn,
} from './types'
