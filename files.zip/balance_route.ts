import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

function getSupabase() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )
}

function verifySecret(req: NextRequest): boolean {
  const secret = req.headers.get('x-telegram-secret')
  return secret === process.env.TELEGRAM_BOT_SECRET
}

export async function POST(req: NextRequest) {
  if (!verifySecret(req)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { telegram_id } = await req.json()

  if (!telegram_id) {
    return NextResponse.json({ error: 'Missing telegram_id' }, { status: 400 })
  }

  const db = getSupabase()

  const profile = await db
    .from('profiles')
    .select('id, username')
    .eq('telegram_id', telegram_id)
    .maybeSingle()

  if (!profile.data) {
    return NextResponse.json({ error: 'User not found' }, { status: 404 })
  }

  const wallet = await db
    .from('wallets')
    .select('balance')
    .eq('user_id', profile.data.id)
    .single()

  return NextResponse.json({
    user_id:  profile.data.id,
    username: profile.data.username,
    balance:  wallet.data?.balance ?? 0,
  })
}
