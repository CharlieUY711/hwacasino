// ============================================================
// SUPABASE SUBSCRIPTION ABSTRACTION
// Wraps Supabase Realtime into a clean, reusable subscription API.
// All subscriptions follow the same contract:
//   subscribe(config) → unsubscribe()
// ============================================================

import { createClient } from '@supabase/supabase-js'
import type { RealtimePostgresChangesPayload } from '@supabase/supabase-js'
import type { RealtimeEvent, RealtimeEventType } from '../../types'

// ── Supabase client ──────────────────────────────────────────
// Single instance shared across all subscriptions.

const supabaseUrl  = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnon, {
  realtime: {
    params: {
      eventsPerSecond: 20,
    },
  },
})

// ── Subscription config ──────────────────────────────────────

export interface SubscriptionConfig<T> {
  /** Unique channel name — must be stable across re-renders */
  channelName: string
  /** Supabase table to subscribe to */
  table: string
  /** Optional filter: e.g. "room_id=eq.abc123" */
  filter?: string
  /** Callback on any change */
  onEvent: (event: RealtimeEvent<T>) => void
  /** Optional error callback */
  onError?: (err: Error) => void
}

// ── Core subscription factory ────────────────────────────────

export function createSubscription<T>(config: SubscriptionConfig<T>) {
  const channel = supabase.channel(config.channelName)

  const postgresConfig: Parameters<typeof channel.on>[1] = {
    event:  '*',
    schema: 'public',
    table:  config.table,
    ...(config.filter ? { filter: config.filter } : {}),
  }

  channel
    .on(
      'postgres_changes' as Parameters<typeof channel.on>[0],
      postgresConfig,
      (payload: RealtimePostgresChangesPayload<Record<string, unknown>>) => {
        const event: RealtimeEvent<T> = {
          eventType:  payload.eventType as RealtimeEventType,
          payload:    (payload.new ?? payload.old) as T,
          oldPayload: payload.old as T | undefined,
          receivedAt: new Date().toISOString(),
        }
        config.onEvent(event)
      }
    )
    .subscribe((status, err) => {
      if (err && config.onError) {
        config.onError(new Error(`Subscription error on ${config.table}: ${err.message}`))
      }
    })

  // Return cleanup function
  return () => {
    supabase.removeChannel(channel)
  }
}

// ── Pre-built subscription factories ────────────────────────
// Each returns an unsubscribe function.

export function subscribeToRounds<T>(
  roomId: string,
  onEvent: SubscriptionConfig<T>['onEvent'],
  onError?: SubscriptionConfig<T>['onError']
) {
  return createSubscription<T>({
    channelName: `rounds:room:${roomId}`,
    table:       'roulette_rounds',
    filter:      `room_id=eq.${roomId}`,
    onEvent,
    onError,
  })
}

export function subscribeToBets<T>(
  roundId: string,
  onEvent: SubscriptionConfig<T>['onEvent'],
  onError?: SubscriptionConfig<T>['onError']
) {
  return createSubscription<T>({
    channelName: `bets:round:${roundId}`,
    table:       'round_bets',
    filter:      `round_id=eq.${roundId}`,
    onEvent,
    onError,
  })
}

export function subscribeToWalletTransactions<T>(
  userId: string,
  onEvent: SubscriptionConfig<T>['onEvent'],
  onError?: SubscriptionConfig<T>['onError']
) {
  return createSubscription<T>({
    channelName: `wallet_txs:user:${userId}`,
    table:       'wallet_transactions',
    filter:      `user_id=eq.${userId}`,
    onEvent,
    onError,
  })
}

export function subscribeToWallet<T>(
  walletId: string,
  onEvent: SubscriptionConfig<T>['onEvent'],
  onError?: SubscriptionConfig<T>['onError']
) {
  return createSubscription<T>({
    channelName: `wallet:${walletId}`,
    table:       'wallets',
    filter:      `id=eq.${walletId}`,
    onEvent,
    onError,
  })
}

// ── Initial data fetchers ────────────────────────────────────
// Used to hydrate state before subscriptions deliver first event.

export async function fetchCurrentRound(roomId: string) {
  const { data, error } = await supabase
    .from('roulette_rounds')
    .select('*')
    .eq('room_id', roomId)
    .order('created_at', { ascending: false })
    .limit(1)
    .single()

  if (error) throw error
  return data
}

export async function fetchRoundBets(roundId: string) {
  const { data, error } = await supabase
    .from('round_bets')
    .select('*')
    .eq('round_id', roundId)
    .order('created_at', { ascending: true })

  if (error) throw error
  return data ?? []
}

export async function fetchWallet(userId: string) {
  const { data, error } = await supabase
    .from('wallets')
    .select('*')
    .eq('user_id', userId)
    .single()

  if (error) throw error
  return data
}

export async function fetchRecentTransactions(userId: string, limit = 10) {
  const { data, error } = await supabase
    .from('wallet_transactions')
    .select('*')
    .eq('user_id', userId)
    .eq('currency', 'CHIPS')
    .order('created_at', { ascending: false })
    .limit(limit)

  if (error) throw error
  return data ?? []
}
