// ============================================================
// useRouletteLive(roomId)
// Subscribes to roulette_rounds filtered by room_id.
// Maintains local state of the current round.
// Emits clean UIRound — never raw DB rows.
// ============================================================

import { useState, useEffect, useCallback, useRef } from 'react'
import { subscribeToRounds, fetchCurrentRound } from '../lib/realtime/subscriptions'
import { normalizeRound } from '../lib/realtime/events'
import type { DBRound, UIRound, UseRouletteLiveReturn, RealtimeEvent } from '../types'

export function useRouletteLive(roomId: string): UseRouletteLiveReturn {
  const [round,       setRound]       = useState<UIRound | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [error,       setError]       = useState<string | null>(null)

  // Track previous status to detect transitions
  const prevStatusRef = useRef<string | null>(null)

  const handleEvent = useCallback((event: RealtimeEvent<DBRound>) => {
    const { eventType, payload } = event

    if (eventType === 'DELETE') {
      setRound(null)
      prevStatusRef.current = null
      return
    }

    if (!payload?.id) return

    const normalized = normalizeRound(payload)

    // Log status transitions (components can subscribe to these via onStatusChange if needed)
    if (prevStatusRef.current && prevStatusRef.current !== normalized.status) {
      console.debug(
        `[useRouletteLive] room:${roomId} status transition:`,
        prevStatusRef.current, '→', normalized.status
      )
    }
    prevStatusRef.current = normalized.status

    setRound(normalized)
  }, [roomId])

  useEffect(() => {
    if (!roomId) return

    let unsubscribe: (() => void) | null = null
    let mounted = true

    async function init() {
      try {
        // 1. Hydrate with current state before subscription fires
        const raw = await fetchCurrentRound(roomId)
        if (mounted && raw) {
          const normalized = normalizeRound(raw as DBRound)
          setRound(normalized)
          prevStatusRef.current = normalized.status
        }

        // 2. Subscribe to live updates
        unsubscribe = subscribeToRounds<DBRound>(
          roomId,
          (event) => {
            if (mounted) handleEvent(event)
          },
          (err) => {
            if (mounted) setError(err.message)
          }
        )

        if (mounted) {
          setIsConnected(true)
          setError(null)
        }
      } catch (err) {
        if (mounted) {
          setError(err instanceof Error ? err.message : 'Failed to connect to round')
          setIsConnected(false)
        }
      }
    }

    init()

    return () => {
      mounted = false
      unsubscribe?.()
      setIsConnected(false)
    }
  }, [roomId, handleEvent])

  return { round, isConnected, error }
}
