// ============================================================
// TYPES — Casino Realtime Layer
// These types model the UI contract, not the DB schema.
// DB rows are always normalized before reaching components.
// ============================================================

// ── DB Row shapes (raw, never exposed to UI) ────────────────

export interface DBRound {
  id: string
  room_id: string
  status: string          // raw DB status: betting | closed | spinning | resolved
  result: number | null
  created_at: string
  updated_at: string
  seed?: string
}

export interface DBBet {
  id: string
  round_id: string
  user_id: string
  amount: number
  choice: string
  payout: number | null
  status: string
  created_at: string
}

export interface DBWalletTransaction {
  id: string
  wallet_id: string
  user_id: string
  currency: string
  type: string
  amount: number
  balance_before: number
  balance_after: number
  status: string
  created_at: string
  metadata: Record<string, unknown>
}

export interface DBWallet {
  id: string
  user_id: string
  balances: Record<string, number>   // { CHIPS: 1000 }
  is_frozen: boolean
  updated_at: string
}

// ── UI Event Types (normalized, safe for components) ────────

export type RoundUIStatus =
  | 'ROUND_BETTING_OPEN'
  | 'ROUND_LOCKED'
  | 'ROUND_SPINNING'
  | 'ROUND_RESOLVED'
  | 'ROUND_UNKNOWN'

export type RealtimeEventType = 'INSERT' | 'UPDATE' | 'DELETE'

export interface UIRound {
  id: string
  roomId: string
  status: RoundUIStatus
  result: number | null
  isBettingOpen: boolean
  isSpinning: boolean
  isResolved: boolean
  startedAt: string
  updatedAt: string
}

export interface UIBet {
  id: string
  roundId: string
  userId: string
  amount: number
  choice: string
  payout: number | null
  status: 'pending' | 'won' | 'lost' | 'refunded'
  placedAt: string
}

export interface UIBetSummary {
  totalAmount: number
  betCount: number
  byChoice: Record<string, number>   // { red: 500, black: 300 }
  byUser: Record<string, number>     // { userId: totalAmount }
  bets: UIBet[]
}

export interface UIWalletState {
  walletId: string
  userId: string
  chips: number
  isFrozen: boolean
  lastTransaction: UITransaction | null
  updatedAt: string
}

export interface UITransaction {
  id: string
  type: string
  amount: number
  balanceBefore: number
  balanceAfter: number
  currency: string
  createdAt: string
}

export interface UIRoomState {
  roomId: string
  currentRound: UIRound | null
  activeBets: UIBetSummary
  connectedAt: string
  isConnected: boolean
}

// ── Subscription event wrappers ──────────────────────────────

export interface RealtimeEvent<T> {
  eventType: RealtimeEventType
  payload: T
  oldPayload?: T
  receivedAt: string
}

// ── Hook return shapes ───────────────────────────────────────

export interface UseRouletteLiveReturn {
  round: UIRound | null
  isConnected: boolean
  error: string | null
}

export interface UseLiveBetsReturn {
  summary: UIBetSummary
  isConnected: boolean
  error: string | null
}

export interface UseWalletLiveReturn {
  wallet: UIWalletState | null
  recentTransactions: UITransaction[]
  isConnected: boolean
  error: string | null
}

export interface UseRoomLiveReturn {
  room: UIRoomState | null
  isConnected: boolean
  error: string | null
}
