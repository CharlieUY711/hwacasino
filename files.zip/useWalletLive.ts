// ============================================================
// useWalletLive(userId)
// Subscribes to wallet + wallet_transactions for a user.
// Updates balance in real time.
// Supports optimistic balance updates for instant UI feedback.
// ============================================================

import { useState, useEffect, useCallback, useRef } from 'react'
import {
  subscribeToWallet,
  subscribeToWalletTransactions,
  fetchWallet,
  fetchRecentTransactions,
} from '../lib/realtime/subscriptions'
import { normalizeWallet, normalizeTransaction } from '../lib/realtime/events'
import type {
  DBWallet,
  DBWalletTransaction,
  UIWalletState,
  UITransaction,
  UseWalletLiveReturn,
  RealtimeEvent,
} from '../types'

const MAX_RECENT_TXS = 10

export function useWalletLive(userId: string | null | undefined): UseWalletLiveReturn {
  const [wallet,             setWallet]             = useState<UIWalletState | null>(null)
  const [recentTransactions, setRecentTransactions] = useState<UITransaction[]>([])
  const [isConnected,        setIsConnected]        = useState(false)
  const [error,              setError]              = useState<string | null>(null)

  // Optimistic balance ref — used to avoid flicker
  const optimisticRef = useRef<number | null>(null)
  const walletIdRef   = useRef<string | null>(null)

  const handleWalletUpdate = useCallback((event: RealtimeEvent<DBWallet>) => {
    const { payload } = event
    if (!payload?.id) return

    const normalized = normalizeWallet(payload)

    // If we have an optimistic balance pending, reconcile:
    // Accept server value only if it's >= optimistic
    // (server is authoritative — optimistic was just for UX speed)
    if (optimisticRef.current !== null) {
      if (normalized.chips >= optimisticRef.current) {
        optimisticRef.current = null
      }
    }

    setWallet(normalized)
  }, [])

  const handleTransaction = useCallback((event: RealtimeEvent<DBWalletTransaction>) => {
    const { eventType, payload } = event
    if (eventType !== 'INSERT' || !payload?.id) return
    if (payload.currency !== 'CHIPS') return

    const tx = normalizeTransaction(payload)

    // Update recent transactions list (prepend, keep max)
    setRecentTransactions(prev => [tx, ...prev].slice(0, MAX_RECENT_TXS))

    // Immediately update displayed balance from the transaction's balance_after
    // This is faster than waiting for the wallet UPDATE event
    setWallet(prev => {
      if (!prev) return prev
      optimisticRef.current = tx.balanceAfter
      return { ...prev, chips: tx.balanceAfter, lastTransaction: tx }
    })
  }, [])

  useEffect(() => {
    if (!userId) {
      setWallet(null)
      setRecentTransactions([])
      setIsConnected(false)
      return
    }

    let unsubWallet: (() => void) | null = null
    let unsubTxs:    (() => void) | null = null
    let mounted = true

    async function init() {
      try {
        // 1. Fetch current wallet state
        const rawWallet = await fetchWallet(userId)
        if (!mounted) return

        walletIdRef.current = rawWallet.id
        setWallet(normalizeWallet(rawWallet as DBWallet))

        // 2. Fetch recent transactions
        const rawTxs = await fetchRecentTransactions(userId)
        if (mounted) {
          setRecentTransactions(rawTxs.map(tx => normalizeTransaction(tx as DBWalletTransaction)))
        }

        // 3. Subscribe to wallet row changes
        unsubWallet = subscribeToWallet<DBWallet>(
          rawWallet.id,
          (event) => {
            if (mounted) handleWalletUpdate(event)
          },
          (err) => {
            if (mounted) setError(err.message)
          }
        )

        // 4. Subscribe to wallet transactions
        unsubTxs = subscribeToWalletTransactions<DBWalletTransaction>(
          userId,
          (event) => {
            if (mounted) handleTransaction(event)
          },
          (err) => {
            if (mounted) setError(err.message)
          }
        )

        if (mounted) {
          setIsConnected(true)
          setError(null)
        }
      } catch (err) {
        if (mounted) {
          setError(err instanceof Error ? err.message : 'Failed to load wallet')
          setIsConnected(false)
        }
      }
    }

    init()

    return () => {
      mounted = false
      unsubWallet?.()
      unsubTxs?.()
      setIsConnected(false)
    }
  }, [userId, handleWalletUpdate, handleTransaction])

  return { wallet, recentTransactions, isConnected, error }
}
