// ============================================================
// useLiveBets(roundId)
// Streams round_bets in real time.
// Aggregates bets per choice and per user.
// Updates instantly when bets change.
// ============================================================

import { useState, useEffect, useCallback } from 'react'
import { subscribeToBets, fetchRoundBets } from '../lib/realtime/subscriptions'
import { normalizeBet, aggregateBets } from '../lib/realtime/events'
import type { DBBet, UIBet, UIBetSummary, UseLiveBetsReturn, RealtimeEvent } from '../types'

const EMPTY_SUMMARY: UIBetSummary = {
  totalAmount: 0,
  betCount:    0,
  byChoice:    {},
  byUser:      {},
  bets:        [],
}

export function useLiveBets(roundId: string | null | undefined): UseLiveBetsReturn {
  const [betsMap,     setBetsMap]     = useState<Map<string, UIBet>>(new Map())
  const [isConnected, setIsConnected] = useState(false)
  const [error,       setError]       = useState<string | null>(null)

  const handleEvent = useCallback((event: RealtimeEvent<DBBet>) => {
    const { eventType, payload } = event

    setBetsMap(prev => {
      const next = new Map(prev)

      if (eventType === 'DELETE') {
        const id = payload?.id ?? event.oldPayload?.id
        if (id) next.delete(id)
        return next
      }

      if (!payload?.id) return prev

      const normalized = normalizeBet(payload)
      next.set(normalized.id, normalized)
      return next
    })
  }, [])

  useEffect(() => {
    if (!roundId) {
      setBetsMap(new Map())
      setIsConnected(false)
      return
    }

    let unsubscribe: (() => void) | null = null
    let mounted = true

    async function init() {
      try {
        // 1. Hydrate with existing bets
        const rows = await fetchRoundBets(roundId)
        if (mounted) {
          const initial = new Map<string, UIBet>()
          for (const row of rows) {
            const bet = normalizeBet(row as DBBet)
            initial.set(bet.id, bet)
          }
          setBetsMap(initial)
        }

        // 2. Subscribe to live bet changes
        unsubscribe = subscribeToBets<DBBet>(
          roundId,
          (event) => {
            if (mounted) handleEvent(event)
          },
          (err) => {
            if (mounted) setError(err.message)
          }
        )

        if (mounted) {
          setIsConnected(true)
          setError(null)
        }
      } catch (err) {
        if (mounted) {
          setError(err instanceof Error ? err.message : 'Failed to load bets')
          setIsConnected(false)
        }
      }
    }

    init()

    return () => {
      mounted = false
      unsubscribe?.()
      setIsConnected(false)
    }
  }, [roundId, handleEvent])

  // Derive aggregated summary from map on every render
  const summary: UIBetSummary = roundId
    ? aggregateBets(Array.from(betsMap.values()))
    : EMPTY_SUMMARY

  return { summary, isConnected, error }
}
