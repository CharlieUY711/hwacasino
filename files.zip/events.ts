// ============================================================
// EVENT NORMALIZATION LAYER
// Single responsibility: DB row → UI shape
// No logic, no state, no side effects. Pure transformation.
// ============================================================

import type {
  DBRound,
  DBBet,
  DBWalletTransaction,
  DBWallet,
  UIRound,
  UIBet,
  UITransaction,
  UIWalletState,
  RoundUIStatus,
} from '../types'

// ── Round status mapping ─────────────────────────────────────

const ROUND_STATUS_MAP: Record<string, RoundUIStatus> = {
  betting:   'ROUND_BETTING_OPEN',
  open:      'ROUND_BETTING_OPEN',   // alias some systems use
  closed:    'ROUND_LOCKED',
  spinning:  'ROUND_SPINNING',
  resolving: 'ROUND_SPINNING',       // treat resolving as still spinning
  resolved:  'ROUND_RESOLVED',
  complete:  'ROUND_RESOLVED',
}

export function normalizeRoundStatus(raw: string): RoundUIStatus {
  return ROUND_STATUS_MAP[raw?.toLowerCase()] ?? 'ROUND_UNKNOWN'
}

// ── DB Row normalizers ───────────────────────────────────────

export function normalizeRound(row: DBRound): UIRound {
  const status = normalizeRoundStatus(row.status)
  return {
    id:            row.id,
    roomId:        row.room_id,
    status,
    result:        row.result ?? null,
    isBettingOpen: status === 'ROUND_BETTING_OPEN',
    isSpinning:    status === 'ROUND_SPINNING',
    isResolved:    status === 'ROUND_RESOLVED',
    startedAt:     row.created_at,
    updatedAt:     row.updated_at,
  }
}

export function normalizeBet(row: DBBet): UIBet {
  return {
    id:       row.id,
    roundId:  row.round_id,
    userId:   row.user_id,
    amount:   row.amount,
    choice:   row.choice,
    payout:   row.payout ?? null,
    status:   normalizeBetStatus(row.status),
    placedAt: row.created_at,
  }
}

function normalizeBetStatus(raw: string): UIBet['status'] {
  const map: Record<string, UIBet['status']> = {
    pending:  'pending',
    won:      'won',
    win:      'won',
    lost:     'lost',
    loss:     'lost',
    refunded: 'refunded',
  }
  return map[raw?.toLowerCase()] ?? 'pending'
}

export function normalizeTransaction(row: DBWalletTransaction): UITransaction {
  return {
    id:             row.id,
    type:           row.type,
    amount:         row.amount,
    balanceBefore:  row.balance_before,
    balanceAfter:   row.balance_after,
    currency:       row.currency,
    createdAt:      row.created_at,
  }
}

export function normalizeWallet(
  row: DBWallet,
  lastTx: DBWalletTransaction | null = null
): UIWalletState {
  return {
    walletId:        row.id,
    userId:          row.user_id,
    chips:           row.balances?.CHIPS ?? 0,
    isFrozen:        row.is_frozen,
    lastTransaction: lastTx ? normalizeTransaction(lastTx) : null,
    updatedAt:       row.updated_at,
  }
}

// ── Bet aggregation ──────────────────────────────────────────

export function aggregateBets(bets: UIBet[]) {
  const byChoice: Record<string, number> = {}
  const byUser:   Record<string, number> = {}
  let totalAmount = 0

  for (const bet of bets) {
    totalAmount += bet.amount

    byChoice[bet.choice] = (byChoice[bet.choice] ?? 0) + bet.amount
    byUser[bet.userId]   = (byUser[bet.userId]   ?? 0) + bet.amount
  }

  return {
    totalAmount,
    betCount: bets.length,
    byChoice,
    byUser,
    bets,
  }
}
