// ============================================================
// useRoomLive(roomId)
// Composes useRouletteLive + useLiveBets to expose a single
// unified room state that all users in the same room share.
// All users in the same room will see identical state.
// ============================================================

import { useState, useEffect, useMemo } from 'react'
import { useRouletteLive } from './useRouletteLive'
import { useLiveBets }     from './useLiveBets'
import type { UIRoomState, UseRoomLiveReturn } from '../types'

export function useRoomLive(roomId: string): UseRoomLiveReturn {
  const [connectedAt, setConnectedAt] = useState<string>(new Date().toISOString())

  const {
    round,
    isConnected: roundConnected,
    error: roundError,
  } = useRouletteLive(roomId)

  const {
    summary,
    isConnected: betsConnected,
    error: betsError,
  } = useLiveBets(round?.id ?? null)

  // Mark connection time once both are ready
  useEffect(() => {
    if (roundConnected && betsConnected) {
      setConnectedAt(new Date().toISOString())
    }
  }, [roundConnected, betsConnected])

  const isConnected = roundConnected && betsConnected
  const error = roundError ?? betsError ?? null

  const room = useMemo<UIRoomState | null>(() => {
    if (!isConnected && !round) return null

    return {
      roomId,
      currentRound: round,
      activeBets:   summary,
      connectedAt,
      isConnected,
    }
  }, [roomId, round, summary, connectedAt, isConnected])

  return { room, isConnected, error }
}
