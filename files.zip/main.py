"""
HWA Casino — Telegram Bot v2
Arquitectura: Bot = HTTP client puro. Sin SDK Supabase.
Todo el game logic pasa por el backend Next.js (hwacasino.com).

Variables de entorno (.env):
  TELEGRAM_BOT_TOKEN
  BACKEND_URL=https://hwacasino.com
  TELEGRAM_BOT_SECRET   (mismo valor que en Vercel env vars)
  PAYPAL_CLIENT_ID
  PAYPAL_CLIENT_SECRET
  PAYPAL_MODE=sandbox
"""

import os
import logging
import httpx
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, ConversationHandler, ContextTypes, filters
)

load_dotenv()
logging.basicConfig(
    format='%(asctime)s — %(name)s — %(levelname)s — %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ══════════════════════════════════════════════════════════════════════════════
# CONFIG
# ══════════════════════════════════════════════════════════════════════════════

BOT_TOKEN      = os.getenv("TELEGRAM_BOT_TOKEN")
BACKEND_URL    = os.getenv("BACKEND_URL", "https://hwacasino.com")
BOT_SECRET     = os.getenv("TELEGRAM_BOT_SECRET", "")
PAYPAL_CLIENT_ID     = os.getenv("PAYPAL_CLIENT_ID")
PAYPAL_CLIENT_SECRET = os.getenv("PAYPAL_CLIENT_SECRET")
PAYPAL_MODE          = os.getenv("PAYPAL_MODE", "sandbox")
MINIAPP_URL          = os.getenv("MINIAPP_URL", "https://hwacasino.com")

PAYPAL_BASE = (
    "https://api-m.paypal.com"
    if PAYPAL_MODE == "live"
    else "https://api-m.sandbox.paypal.com"
)

NECTAR_PER_USD  = 1000
MIN_DEPOSIT_USD = 10
MAX_DEPOSIT_USD = 1000
TELEGRAM_ROOM   = "telegram"

# Ruleta
RED_NUMBERS  = {1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36}
BLACK_NUMBERS= {2,4,6,8,10,11,13,15,17,20,22,24,26,28,29,31,33,35}

# Estados ConversationHandler
(VIP_WAITING,) = range(1)

# ══════════════════════════════════════════════════════════════════════════════
# BACKEND API CLIENT
# ══════════════════════════════════════════════════════════════════════════════

def _headers() -> dict:
    return {
        "Content-Type":     "application/json",
        "x-telegram-secret": BOT_SECRET,
    }


async def api_register(telegram_id: int, username: str, invite_code: str) -> dict:
    async with httpx.AsyncClient(timeout=15) as client:
        res = await client.post(
            f"{BACKEND_URL}/api/telegram/register",
            json={"telegram_id": telegram_id, "username": username, "invite_code": invite_code},
            headers=_headers(),
        )
    if res.status_code == 400:
        raise ValueError(res.json().get("error", "Invalid invite code"))
    res.raise_for_status()
    return res.json()


async def api_balance(telegram_id: int) -> dict:
    async with httpx.AsyncClient(timeout=10) as client:
        res = await client.post(
            f"{BACKEND_URL}/api/telegram/balance",
            json={"telegram_id": telegram_id},
            headers=_headers(),
        )
    if res.status_code == 404:
        return None
    res.raise_for_status()
    return res.json()


async def api_round_status(room_id: str = TELEGRAM_ROOM) -> dict:
    async with httpx.AsyncClient(timeout=10) as client:
        res = await client.get(
            f"{BACKEND_URL}/api/roulette/round/status",
            params={"room": room_id},
            headers=_headers(),
        )
    res.raise_for_status()
    return res.json()


async def api_place_bet(user_id: str, round_id: str, bets: list) -> dict:
    async with httpx.AsyncClient(timeout=10) as client:
        res = await client.post(
            f"{BACKEND_URL}/api/roulette/round/bet",
            json={"user_id": user_id, "round_id": round_id, "bets": bets},
            headers=_headers(),
        )
    res.raise_for_status()
    return res.json()

# ══════════════════════════════════════════════════════════════════════════════
# PAYPAL
# ══════════════════════════════════════════════════════════════════════════════

async def paypal_get_token() -> str:
    async with httpx.AsyncClient() as client:
        res = await client.post(
            f"{PAYPAL_BASE}/v1/oauth2/token",
            auth=(PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET),
            data={"grant_type": "client_credentials"},
        )
    res.raise_for_status()
    return res.json()["access_token"]


async def paypal_create_order(user_id: str, amount_usd: float) -> dict:
    token   = await paypal_get_token()
    nectar  = int(amount_usd * NECTAR_PER_USD)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    body = {
        "intent": "CAPTURE",
        "purchase_units": [{
            "amount": {"currency_code": "USD", "value": f"{amount_usd:.2f}"},
            "description": f"HWA Casino - {nectar} Nectar",
            "custom_id": user_id,
        }],
        "application_context": {
            "brand_name":  "HWA Casino",
            "user_action": "PAY_NOW",
            "return_url":  f"{MINIAPP_URL}/deposit/success",
            "cancel_url":  f"{MINIAPP_URL}/deposit",
        },
    }
    async with httpx.AsyncClient() as client:
        res = await client.post(f"{PAYPAL_BASE}/v2/checkout/orders", json=body, headers=headers)
    res.raise_for_status()
    data        = res.json()
    approve_url = next((l["href"] for l in data["links"] if l["rel"] == "approve"), None)
    return {"order_id": data["id"], "approve_url": approve_url, "nectar": nectar}


async def paypal_capture_order(order_id: str) -> dict:
    token   = await paypal_get_token()
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    async with httpx.AsyncClient() as client:
        res = await client.post(
            f"{PAYPAL_BASE}/v2/checkout/orders/{order_id}/capture",
            headers=headers, json={},
        )
    data = res.json()
    if data.get("status") != "COMPLETED":
        raise ValueError(f"Pago no completado: {data.get('status')}")
    unit    = data["purchase_units"][0]
    paid    = float(unit["payments"]["captures"][0]["amount"]["value"])
    user_id = unit.get("custom_id") or unit["payments"]["captures"][0].get("custom_id")
    return {"paid_usd": paid, "user_id": user_id}

# ══════════════════════════════════════════════════════════════════════════════
# HELPERS UI
# ══════════════════════════════════════════════════════════════════════════════

def fmt_nectar(n: int) -> str:
    return f"{n:,} Nectar".replace(",", ".")


def get_color(n: int) -> str:
    if n == 0: return "green"
    return "red" if n in RED_NUMBERS else "black"


def color_emoji(n: int) -> str:
    return {"red": "\U0001f534", "black": "\u26ab", "green": "\U0001f7e2"}[get_color(n)]


def main_menu_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("\U0001f3a1 Ruleta",    callback_data="menu_roulette"),
         InlineKeyboardButton("\U0001f4b3 Depositar", callback_data="menu_deposit")],
        [InlineKeyboardButton("\U0001f4b0 Balance",   callback_data="menu_balance")],
    ])

# ══════════════════════════════════════════════════════════════════════════════
# HANDLERS — INICIO Y VIP
# ══════════════════════════════════════════════════════════════════════════════

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    tg_id   = update.effective_user.id
    tg_name = update.effective_user.username or update.effective_user.first_name

    user = await api_balance(tg_id)

    if user:
        await update.message.reply_text(
            f"\u2660\ufe0f *Bienvenido de vuelta, {user['username']}*\n\n"
            f"\U0001f4b0 Balance: *{fmt_nectar(user['balance'])}*\n\n"
            f"Que queres hacer?",
            parse_mode="Markdown",
            reply_markup=main_menu_keyboard(),
        )
        return ConversationHandler.END

    await update.message.reply_text(
        "\u2660\ufe0f *HWA Casino*\n\n"
        "_Plataforma privada. Solo por invitacion._\n\n"
        "Ingresa tu codigo VIP para continuar:",
        parse_mode="Markdown",
    )
    return VIP_WAITING


async def vip_code_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    tg_id   = update.effective_user.id
    tg_name = update.effective_user.username or update.effective_user.first_name
    code    = update.message.text.strip()

    try:
        user = await api_register(tg_id, tg_name, code)
    except ValueError as e:
        await update.message.reply_text(
            f"\u274c Codigo invalido o ya utilizado.\n"
            f"Verifica el codigo e intenta de nuevo."
        )
        return VIP_WAITING
    except Exception as e:
        logger.error(f"Error registrando {tg_id}: {e}")
        await update.message.reply_text("\u274c Error al registrar tu cuenta. Contacta soporte.")
        return ConversationHandler.END

    await update.message.reply_text(
        f"\u2705 *Bienvenido a HWA Casino, {user['username']}*\n\n"
        f"\U0001f381 Recibiste *{fmt_nectar(1000)}* de bienvenida.\n\n"
        f"Que queres hacer?",
        parse_mode="Markdown",
        reply_markup=main_menu_keyboard(),
    )
    return ConversationHandler.END


async def cmd_menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    tg_id = update.effective_user.id
    user  = await api_balance(tg_id)
    if not user:
        await update.message.reply_text("\u274c Usa /start para registrarte primero.")
        return
    await update.message.reply_text(
        f"\u2660\ufe0f *HWA Casino*\n\U0001f4b0 {fmt_nectar(user['balance'])}",
        parse_mode="Markdown",
        reply_markup=main_menu_keyboard(),
    )


async def cmd_balance(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    tg_id = update.effective_user.id
    user  = await api_balance(tg_id)
    if not user:
        await update.message.reply_text("\u274c Usa /start para registrarte primero.")
        return
    await update.message.reply_text(
        f"\U0001f4b0 *Tu balance*\n\n*{fmt_nectar(user['balance'])}*",
        parse_mode="Markdown",
    )

# ══════════════════════════════════════════════════════════════════════════════
# HANDLERS — MENU CALLBACKS
# ══════════════════════════════════════════════════════════════════════════════

async def menu_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data  = query.data
    tg_id = update.effective_user.id

    user = await api_balance(tg_id)
    if not user:
        await query.edit_message_text("\u274c Sesion expirada. Usa /start.")
        return

    if data == "menu_balance":
        await query.edit_message_text(
            f"\U0001f4b0 *Tu balance*\n\n*{fmt_nectar(user['balance'])}*\n\n"
            f"1 USD = {NECTAR_PER_USD}.000 Nectar",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001f4b3 Depositar", callback_data="menu_deposit"),
                 InlineKeyboardButton("\u25c0\ufe0f Menu",    callback_data="menu_back")],
            ])
        )

    elif data == "menu_roulette":
        await show_roulette_menu(query, user)

    elif data == "menu_deposit":
        await show_deposit_menu(query, user)

    elif data == "menu_back":
        user = await api_balance(tg_id)
        await query.edit_message_text(
            f"\u2660\ufe0f *HWA Casino*\n\U0001f4b0 {fmt_nectar(user['balance'])}",
            parse_mode="Markdown",
            reply_markup=main_menu_keyboard(),
        )

# ══════════════════════════════════════════════════════════════════════════════
# HANDLERS — RULETA (consume /api/roulette/round/*)
# ══════════════════════════════════════════════════════════════════════════════

BET_LABELS = {
    "red":    ("\U0001f534 Rojo",    "1:1"),
    "black":  ("\u26ab Negro",       "1:1"),
    "odd":    ("Impar",              "1:1"),
    "even":   ("Par",                "1:1"),
    "low":    ("1-18",               "1:1"),
    "high":   ("19-36",              "1:1"),
    "dozen1": ("1a Docena",          "2:1"),
    "dozen2": ("2a Docena",          "2:1"),
    "dozen3": ("3a Docena",          "2:1"),
    "col1":   ("Col 1",              "2:1"),
    "col2":   ("Col 2",              "2:1"),
    "col3":   ("Col 3",              "2:1"),
}


async def show_roulette_menu(query, user: dict):
    balance = user["balance"]
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("\U0001f534 Rojo",     callback_data="rt_red"),
         InlineKeyboardButton("\u26ab Negro",        callback_data="rt_black"),
         InlineKeyboardButton("\U0001f7e2 Cero",     callback_data="rt_number_0")],
        [InlineKeyboardButton("Impar",               callback_data="rt_odd"),
         InlineKeyboardButton("Par",                 callback_data="rt_even")],
        [InlineKeyboardButton("1-18",                callback_data="rt_low"),
         InlineKeyboardButton("19-36",               callback_data="rt_high")],
        [InlineKeyboardButton("1a Docena",           callback_data="rt_dozen1"),
         InlineKeyboardButton("2a Docena",           callback_data="rt_dozen2"),
         InlineKeyboardButton("3a Docena",           callback_data="rt_dozen3")],
        [InlineKeyboardButton("Col 1 (2:1)",         callback_data="rt_col1"),
         InlineKeyboardButton("Col 2 (2:1)",         callback_data="rt_col2"),
         InlineKeyboardButton("Col 3 (2:1)",         callback_data="rt_col3")],
        [InlineKeyboardButton("\u25c0\ufe0f Menu",   callback_data="menu_back")],
    ])
    await query.edit_message_text(
        f"\U0001f3a1 *RULETA*\n"
        f"\U0001f4b0 Balance: *{fmt_nectar(balance)}*\n\n"
        f"Elige tu tipo de apuesta:",
        parse_mode="Markdown",
        reply_markup=keyboard,
    )


async def roulette_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data  = query.data
    tg_id = update.effective_user.id

    user = await api_balance(tg_id)
    if not user:
        await query.edit_message_text("\u274c Sesion expirada. Usa /start.")
        return

    # Seleccion de tipo de apuesta
    if not data.startswith("rt_amt_"):
        parts     = data[3:].split("_")
        bet_type  = parts[0]
        bet_value = parts[1] if len(parts) > 1 else None

        ctx.user_data["rt_type"]  = bet_type
        ctx.user_data["rt_value"] = bet_value

        label, payout_info = BET_LABELS.get(bet_type, (f"Numero {bet_value}", "35:1"))

        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("10 N",     callback_data="rt_amt_10"),
             InlineKeyboardButton("50 N",     callback_data="rt_amt_50"),
             InlineKeyboardButton("100 N",    callback_data="rt_amt_100")],
            [InlineKeyboardButton("250 N",    callback_data="rt_amt_250"),
             InlineKeyboardButton("500 N",    callback_data="rt_amt_500"),
             InlineKeyboardButton("1.000 N",  callback_data="rt_amt_1000")],
            [InlineKeyboardButton("5.000 N",  callback_data="rt_amt_5000"),
             InlineKeyboardButton("10.000 N", callback_data="rt_amt_10000")],
            [InlineKeyboardButton("\u25c0\ufe0f Volver", callback_data="menu_roulette")],
        ])
        await query.edit_message_text(
            f"\U0001f3a1 *RULETA \u2014 {label}* ({payout_info})\n"
            f"\U0001f4b0 Balance: *{fmt_nectar(user['balance'])}*\n\n"
            f"Elige cuanto apostar:",
            parse_mode="Markdown",
            reply_markup=keyboard,
        )
        return

    # Apuesta con monto — llama al engine del backend
    bet_amount = int(data.split("_")[-1])
    bet_type   = ctx.user_data.get("rt_type")
    bet_value  = ctx.user_data.get("rt_value")

    if not bet_type:
        await query.edit_message_text("\u274c Error. Usa /menu para volver.")
        return

    if user["balance"] < bet_amount:
        await query.answer(
            f"Saldo insuficiente. Tenes {fmt_nectar(user['balance'])}.",
            show_alert=True
        )
        return

    await query.edit_message_text("\U0001f3a1 Esperando ronda...\n\n\U0001f504")

    try:
        # 1. Obtener ronda activa
        round_data = await api_round_status(TELEGRAM_ROOM)
        round_id   = round_data["round_id"]
        status     = round_data["status"]
        secs       = round_data.get("seconds_remaining", 0)

        if status != "betting":
            await query.edit_message_text(
                f"\u23f3 *Ronda cerrada*\n\n"
                f"La ruleta esta girando o la ronda cerro.\n"
                f"Intenta en unos segundos.",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\U0001f504 Reintentar", callback_data=f"rt_amt_{bet_amount}"),
                     InlineKeyboardButton("\u25c0\ufe0f Menu",     callback_data="menu_back")],
                ])
            )
            return

        # 2. Registrar apuesta
        bet_entry = {
            "bet_type":  bet_type if bet_type != "number" else "number",
            "bet_value": bet_value or bet_type,
            "amount":    bet_amount,
        }
        await api_place_bet(user["user_id"], round_id, [bet_entry])

        # 3. Confirmar y mostrar countdown
        label, _ = BET_LABELS.get(bet_type, (f"Numero {bet_value}", "35:1"))
        await query.edit_message_text(
            f"\u2705 *Apuesta registrada*\n\n"
            f"Tipo: *{label}*\n"
            f"Monto: *{fmt_nectar(bet_amount)}*\n\n"
            f"\u23f1 La ruleta gira en *{secs}s*\n"
            f"Usa /resultado para ver el resultado.",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001f3ae Ver resultado", callback_data="rt_result"),
                 InlineKeyboardButton("\u25c0\ufe0f Menu",        callback_data="menu_back")],
            ])
        )

    except Exception as e:
        logger.error(f"Error en ruleta para {tg_id}: {e}")
        await query.edit_message_text(
            "\u274c Error al registrar la apuesta.\n"
            "Intenta de nuevo o contacta soporte.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\u25c0\ufe0f Menu", callback_data="menu_back")]
            ])
        )


async def roulette_result_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    tg_id = update.effective_user.id

    try:
        round_data = await api_round_status(TELEGRAM_ROOM)
        status     = round_data["status"]

        if status != "closed":
            secs = round_data.get("seconds_remaining", "?")
            await query.edit_message_text(
                f"\u23f3 *Ronda en curso*\n\n"
                f"Faltan ~{secs}s para el resultado.\n"
                f"Vuelve a intentarlo en un momento.",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\U0001f504 Actualizar", callback_data="rt_result"),
                     InlineKeyboardButton("\u25c0\ufe0f Menu",     callback_data="menu_back")],
                ])
            )
            return

        num   = round_data.get("winning_number")
        emoji = color_emoji(num)
        color = {"red": "Rojo", "black": "Negro", "green": "Verde"}[get_color(num)]
        user  = await api_balance(tg_id)
        bal   = fmt_nectar(user["balance"]) if user else "?"

        await query.edit_message_text(
            f"\U0001f3b0 *RESULTADO*\n\n"
            f"\u2554\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557\n"
            f"\u2551  {emoji} {num}  {color}\n"
            f"\u255a\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255d\n\n"
            f"\U0001f4b0 Balance actual: *{bal}*",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001f3a1 Jugar de nuevo", callback_data="menu_roulette"),
                 InlineKeyboardButton("\u25c0\ufe0f Menu",         callback_data="menu_back")],
            ])
        )

    except Exception as e:
        logger.error(f"Error obteniendo resultado para {tg_id}: {e}")
        await query.edit_message_text("\u274c Error obteniendo resultado. Intenta de nuevo.")

# ══════════════════════════════════════════════════════════════════════════════
# HANDLERS — DEPOSITO PAYPAL
# ══════════════════════════════════════════════════════════════════════════════

PRESET_DEPOSIT_USD = [10, 25, 50, 100, 250, 500]


async def show_deposit_menu(query, user: dict):
    balance      = user["balance"]
    keyboard_rows= []
    row          = []
    for usd in PRESET_DEPOSIT_USD:
        nectar = usd * NECTAR_PER_USD
        row.append(InlineKeyboardButton(
            f"${usd} = {nectar//1000}K N",
            callback_data=f"dep_amt_{usd}"
        ))
        if len(row) == 3:
            keyboard_rows.append(row)
            row = []
    if row:
        keyboard_rows.append(row)
    keyboard_rows.append([InlineKeyboardButton("\u25c0\ufe0f Menu", callback_data="menu_back")])

    await query.edit_message_text(
        f"\U0001f4b3 *DEPOSITAR NECTAR*\n"
        f"Balance actual: *{fmt_nectar(balance)}*\n\n"
        f"1 USD = 1.000 Nectar\n"
        f"Minimo: ${MIN_DEPOSIT_USD} | Maximo: ${MAX_DEPOSIT_USD}\n\n"
        f"Elige el monto:",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard_rows),
    )


async def deposit_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data  = query.data
    tg_id = update.effective_user.id

    user = await api_balance(tg_id)
    if not user:
        await query.edit_message_text("\u274c Sesion expirada. Usa /start.")
        return

    if data.startswith("dep_amt_"):
        usd    = int(data.split("_")[-1])
        nectar = usd * NECTAR_PER_USD
        ctx.user_data["dep_usd"]    = usd
        ctx.user_data["dep_nectar"] = nectar
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("\u2705 Confirmar y pagar con PayPal", callback_data="dep_confirm")],
            [InlineKeyboardButton("\u25c0\ufe0f Cambiar monto", callback_data="menu_deposit")],
        ])
        await query.edit_message_text(
            f"\U0001f4b3 *Resumen del deposito*\n\n"
            f"Pagas: *${usd:.2f} USD*\n"
            f"Recibes: *{fmt_nectar(nectar)}*\n\n"
            f"Pago procesado por PayPal.",
            parse_mode="Markdown",
            reply_markup=keyboard,
        )

    elif data == "dep_confirm":
        usd    = ctx.user_data.get("dep_usd")
        nectar = ctx.user_data.get("dep_nectar")
        if not usd:
            await query.edit_message_text("\u274c Error. Usa /menu para volver.")
            return

        await query.edit_message_text("\u23f3 Generando link de pago PayPal...")

        try:
            order = await paypal_create_order(user["user_id"], usd)
            ctx.user_data["dep_order_id"] = order["order_id"]
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("\U0001f4b3 Pagar con PayPal", url=order["approve_url"])],
                [InlineKeyboardButton("\u2705 Ya pague \u2014 verificar", callback_data=f"dep_capture_{order['order_id']}")],
                [InlineKeyboardButton("\u274c Cancelar", callback_data="menu_back")],
            ])
            await query.edit_message_text(
                f"\u2705 *Link de pago generado*\n\n"
                f"Monto: *${usd:.2f} USD*\n"
                f"Nectar a acreditar: *{fmt_nectar(nectar)}*\n\n"
                f"1. Presiona *Pagar con PayPal*\n"
                f"2. Completa el pago en el navegador\n"
                f"3. Vuelve y presiona *Ya pague \u2014 verificar*\n\n"
                f"_El link expira en 3 horas._",
                parse_mode="Markdown",
                reply_markup=keyboard,
            )
        except Exception as e:
            logger.error(f"Error creando orden PayPal: {e}")
            await query.edit_message_text(
                "\u274c Error generando el link de pago.\n"
                "Intenta de nuevo o contacta soporte."
            )

    elif data.startswith("dep_capture_"):
        order_id = data.split("dep_capture_")[-1]
        await query.edit_message_text("\u23f3 Verificando pago...")
        try:
            await paypal_capture_order(order_id)
            user = await api_balance(tg_id)
            await query.edit_message_text(
                f"\u2705 *Deposito confirmado*\n\n"
                f"Balance nuevo: *{fmt_nectar(user['balance'])}*\n\n"
                f"Buena suerte!",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\U0001f3a1 Jugar Ruleta", callback_data="menu_roulette"),
                     InlineKeyboardButton("\u25c0\ufe0f Menu",       callback_data="menu_back")],
                ])
            )
        except ValueError:
            await query.edit_message_text(
                f"\u23f3 *Pago pendiente*\n\nEl pago aun no fue confirmado por PayPal.",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("\U0001f504 Verificar de nuevo", callback_data=f"dep_capture_{order_id}")],
                    [InlineKeyboardButton("\u274c Cancelar", callback_data="menu_back")],
                ])
            )
        except Exception as e:
            logger.error(f"Error capturando orden {order_id}: {e}")
            await query.edit_message_text(
                "\u274c Error verificando el pago.\n"
                "Si ya pagaste, contacta soporte con tu comprobante."
            )

# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    if not BOT_TOKEN:
        raise ValueError("TELEGRAM_BOT_TOKEN no configurado")
    if not BACKEND_URL:
        raise ValueError("BACKEND_URL no configurado")

    app = Application.builder().token(BOT_TOKEN).build()

    vip_conv = ConversationHandler(
        entry_points=[CommandHandler("start", cmd_start)],
        states={
            VIP_WAITING: [MessageHandler(filters.TEXT & ~filters.COMMAND, vip_code_handler)],
        },
        fallbacks=[CommandHandler("start", cmd_start)],
        per_message=False,
    )

    app.add_handler(vip_conv)
    app.add_handler(CommandHandler("menu",    cmd_menu))
    app.add_handler(CommandHandler("balance", cmd_balance))

    app.add_handler(CallbackQueryHandler(menu_callback,           pattern=r"^menu_"))
    app.add_handler(CallbackQueryHandler(roulette_callback,       pattern=r"^rt_(?!result)"))
    app.add_handler(CallbackQueryHandler(roulette_result_callback,pattern=r"^rt_result"))
    app.add_handler(CallbackQueryHandler(deposit_callback,        pattern=r"^dep_"))

    logger.info("HWA Casino Bot v2 iniciado")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
