'use client'

// ============================================================
// RouletteView — integration example
// Shows how the realtime hooks compose into a live UI.
// No game logic. No SQL. Pure state consumption.
// ============================================================

import React from 'react'
import { useRoomLive }   from '../hooks/useRoomLive'
import { useWalletLive } from '../hooks/useWalletLive'
import type { UIRound, UIBetSummary, UIWalletState } from '../types'

interface RouletteViewProps {
  roomId: string
  userId: string
}

export function RouletteView({ roomId, userId }: RouletteViewProps) {
  const { room, isConnected, error } = useRoomLive(roomId)
  const { wallet }                   = useWalletLive(userId)

  if (error) {
    return <ConnectionError message={error} />
  }

  if (!isConnected || !room) {
    return <ConnectingScreen />
  }

  return (
    <div className="roulette-view">
      <Header wallet={wallet} isConnected={isConnected} />

      <RoundStatus round={room.currentRound} />

      <BetBoard
        summary={room.activeBets}
        isBettingOpen={room.currentRound?.isBettingOpen ?? false}
      />

      {room.currentRound?.isResolved && room.currentRound.result !== null && (
        <ResultDisplay result={room.currentRound.result} />
      )}
    </div>
  )
}

// ── Sub-components ───────────────────────────────────────────

function Header({
  wallet,
  isConnected,
}: {
  wallet: UIWalletState | null
  isConnected: boolean
}) {
  return (
    <header className="roulette-header">
      <div className="connection-badge" data-connected={isConnected}>
        {isConnected ? '● LIVE' : '○ Connecting'}
      </div>
      <div className="balance">
        {wallet ? (
          <>
            <span className="balance-amount">
              {wallet.chips.toLocaleString('es-UY')}
            </span>
            <span className="balance-currency">CHIPS</span>
          </>
        ) : (
          <span className="balance-loading">—</span>
        )}
      </div>
    </header>
  )
}

function RoundStatus({ round }: { round: UIRound | null }) {
  if (!round) return <div className="round-status">Waiting for round...</div>

  const statusLabels: Record<string, string> = {
    ROUND_BETTING_OPEN: '🟢 Bets Open',
    ROUND_LOCKED:       '🔴 Bets Closed',
    ROUND_SPINNING:     '🎰 Spinning...',
    ROUND_RESOLVED:     `✅ Result: ${round.result}`,
    ROUND_UNKNOWN:      '⏳ Loading',
  }

  return (
    <div className="round-status" data-status={round.status}>
      <span className="status-label">{statusLabels[round.status]}</span>
      <span className="round-id">Round #{round.id.slice(0, 8)}</span>
    </div>
  )
}

function BetBoard({
  summary,
  isBettingOpen,
}: {
  summary: UIBetSummary
  isBettingOpen: boolean
}) {
  return (
    <div className="bet-board" data-open={isBettingOpen}>
      <div className="bet-totals">
        <span>Total wagered: {summary.totalAmount.toLocaleString('es-UY')} CHIPS</span>
        <span>{summary.betCount} bet{summary.betCount !== 1 ? 's' : ''}</span>
      </div>

      {Object.keys(summary.byChoice).length > 0 && (
        <div className="bet-breakdown">
          {Object.entries(summary.byChoice).map(([choice, amount]) => (
            <div key={choice} className="bet-choice-row">
              <span className="choice-label">{choice}</span>
              <span className="choice-amount">{amount.toLocaleString('es-UY')}</span>
            </div>
          ))}
        </div>
      )}

      {!isBettingOpen && (
        <div className="betting-closed-overlay">Betting closed</div>
      )}
    </div>
  )
}

function ResultDisplay({ result }: { result: number }) {
  const isRed   = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36].includes(result)
  const color   = result === 0 ? 'green' : isRed ? 'red' : 'black'

  return (
    <div className="result-display" data-color={color}>
      <div className="result-number">{result}</div>
      <div className="result-color">{color.toUpperCase()}</div>
    </div>
  )
}

function ConnectingScreen() {
  return (
    <div className="connecting-screen">
      <div className="connecting-spinner" />
      <p>Connecting to live room...</p>
    </div>
  )
}

function ConnectionError({ message }: { message: string }) {
  return (
    <div className="connection-error">
      <p>Connection error: {message}</p>
      <button onClick={() => window.location.reload()}>Retry</button>
    </div>
  )
}
