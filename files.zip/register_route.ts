import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

function getSupabase() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )
}

function verifySecret(req: NextRequest): boolean {
  const secret = req.headers.get('x-telegram-secret')
  return secret === process.env.TELEGRAM_BOT_SECRET
}

export async function POST(req: NextRequest) {
  if (!verifySecret(req)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { telegram_id, username, invite_code } = await req.json()

  if (!telegram_id || !invite_code) {
    return NextResponse.json({ error: 'Missing fields' }, { status: 400 })
  }

  const db = getSupabase()

  // 1. Idempotente — si ya existe, retornar
  const existing = await db
    .from('profiles')
    .select('id, username')
    .eq('telegram_id', telegram_id)
    .maybeSingle()

  if (existing.data) {
    const wallet = await db
      .from('wallets')
      .select('balance')
      .eq('user_id', existing.data.id)
      .single()

    return NextResponse.json({
      user_id:  existing.data.id,
      username: existing.data.username,
      balance:  wallet.data?.balance ?? 0,
      created:  false,
    })
  }

  // 2. Validar invite
  const invite = await db
    .from('invites')
    .select('*')
    .eq('code', invite_code.trim().toUpperCase())
    .eq('used', false)
    .maybeSingle()

  if (!invite.data) {
    return NextResponse.json({ error: 'Invalid or used invite code' }, { status: 400 })
  }

  // 3. Crear auth user (necesario por FK profiles.id -> auth.users.id)
  const fakeEmail    = `${telegram_id}@tg.hwacasino.com`
  const fakePassword = crypto.randomUUID() + crypto.randomUUID()

  const authRes = await db.auth.admin.createUser({
    email:           fakeEmail,
    password:        fakePassword,
    email_confirm:   true,
    user_metadata:   { telegram_id, username, source: 'telegram' },
  })

  if (authRes.error) {
    console.error('[telegram/register] auth.admin.createUser error:', authRes.error)
    return NextResponse.json({ error: 'Failed to create user' }, { status: 500 })
  }

  const userId = authRes.data.user.id

  // 4. Actualizar profile con telegram_id y username
  //    (el trigger handle_new_user ya creo el profile y wallet)
  await db
    .from('profiles')
    .update({ telegram_id, username, role: 'player' })
    .eq('id', userId)

  // 5. Marcar invite como usada
  await db
    .from('invites')
    .update({
      used:            true,
      used_by:         String(telegram_id),
      used_at:         new Date().toISOString(),
      invited_user_id: userId,
    })
    .eq('code', invite_code.trim().toUpperCase())

  // 6. Registrar transaccion de bienvenida
  await db.from('transactions').insert({
    user_id:   userId,
    type:      'welcome_bonus',
    amount:    1000,
    direction: 'credit',
    metadata:  { platform: 'telegram' },
  })

  // 7. Balance inicial (trigger ya creo 1000 Nectar)
  const wallet = await db
    .from('wallets')
    .select('balance')
    .eq('user_id', userId)
    .single()

  return NextResponse.json({
    user_id:  userId,
    username,
    balance:  wallet.data?.balance ?? 1000,
    created:  true,
  })
}
