import { NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const db = () => createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function GET(req: NextRequest) {
  const token = req.nextUrl.searchParams.get("token")
  if (!token) return NextResponse.json({ error: "Missing token" }, { status: 400 })

  const supabase = db()

  // Buscar token válido
  const { data: row } = await supabase
    .from("telegram_tokens")
    .select("user_id, expires_at, used")
    .eq("token", token)
    .maybeSingle()

  if (!row) return NextResponse.json({ error: "Invalid token" }, { status: 401 })
  if (row.used) return NextResponse.json({ error: "Token already used" }, { status: 401 })
  if (new Date(row.expires_at) < new Date()) return NextResponse.json({ error: "Token expired" }, { status: 401 })

  // Marcar como usado
  await supabase.from("telegram_tokens").update({ used: true }).eq("token", token)

  // Crear sesión para el usuario
  const { data: session, error } = await supabase.auth.admin.createSession({ userId: row.user_id })
  if (error || !session) return NextResponse.json({ error: "Failed to create session" }, { status: 500 })

  return NextResponse.json({
    access_token: session.session.access_token,
    refresh_token: session.session.refresh_token,
  })
}
